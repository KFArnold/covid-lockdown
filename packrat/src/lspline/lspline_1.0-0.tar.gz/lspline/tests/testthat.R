library(testthat)
library(lspline)

test_check("lspline")
