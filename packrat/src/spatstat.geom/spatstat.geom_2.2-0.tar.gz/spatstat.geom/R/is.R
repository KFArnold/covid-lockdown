##  is.R
## original for spatstat.geom

is.lpp <- function(x) { inherits(x, "lpp") }

is.fv <- function(x) { inherits(x, "fv") }

is.linim <- function(x) { inherits(x, "linim") }

