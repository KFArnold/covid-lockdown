##  is.R
## original for spatstat.core

is.lppm <- function(x) { inherits(x, "lppm") }

